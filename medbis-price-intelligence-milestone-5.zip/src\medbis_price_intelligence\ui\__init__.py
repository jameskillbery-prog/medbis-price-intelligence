"""Desktop user interface components."""

