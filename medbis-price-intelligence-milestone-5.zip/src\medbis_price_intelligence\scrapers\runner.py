import asyncio
import json
from collections.abc import Callable
from datetime import datetime
from decimal import Decimal

from playwright.async_api import async_playwright
from sqlalchemy.orm import Session

from medbis_price_intelligence.scrapers.base import BaseScraper
from medbis_price_intelligence.scrapers.cache import ScrapeCacheRepository
from medbis_price_intelligence.scrapers.models import ScraperQuery, ScraperResult

ScraperFactory = Callable[..., BaseScraper]


class ScraperRunner:
    """Runs multiple Playwright scrapers concurrently."""

    def __init__(
        self,
        scraper_factories: list[ScraperFactory],
        session: Session | None = None,
        cache_days: int = 14,
        concurrency_limit: int = 4,
    ) -> None:
        self.scraper_factories = scraper_factories
        self.session = session
        self.cache_days = cache_days
        self.concurrency_limit = concurrency_limit

    async def run(self, query: ScraperQuery) -> dict[str, list[ScraperResult]]:
        """Run all configured scrapers and return results grouped by competitor."""
        semaphore = asyncio.Semaphore(self.concurrency_limit)
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True)
            try:
                context = await browser.new_context()
                scrapers = [factory(context) for factory in self.scraper_factories]
                tasks = [self._run_one(scraper, query, semaphore) for scraper in scrapers]
                scraper_results = await asyncio.gather(*tasks)
                return dict(scraper_results)
            finally:
                await browser.close()

    async def _run_one(
        self,
        scraper: BaseScraper,
        query: ScraperQuery,
        semaphore: asyncio.Semaphore,
    ) -> tuple[str, list[ScraperResult]]:
        async with semaphore:
            cached = self._get_cached(scraper.name, query.search_term)
            if cached is not None:
                return scraper.name, cached

            results = await scraper.search(query)
            self._set_cached(scraper.name, query.search_term, results)
            return scraper.name, results

    def _get_cached(self, competitor_name: str, search_term: str) -> list[ScraperResult] | None:
        if self.session is None:
            return None
        payload = ScrapeCacheRepository(self.session).get_fresh(
            competitor_name,
            search_term,
            self.cache_days,
        )
        if payload is None:
            return None
        values = json.loads(payload)
        return [self._deserialise_result(value) for value in values]

    def _set_cached(
        self,
        competitor_name: str,
        search_term: str,
        results: list[ScraperResult],
    ) -> None:
        if self.session is None:
            return
        payload = json.dumps([self._serialise_result(result) for result in results])
        ScrapeCacheRepository(self.session).set(competitor_name, search_term, payload)

    @staticmethod
    def _serialise_result(result: ScraperResult) -> dict[str, object]:
        return {
            "product_name": result.product_name,
            "brand": result.brand,
            "price": str(result.price) if result.price is not None else None,
            "stock": result.stock,
            "url": result.url,
            "confidence": result.confidence,
            "timestamp": result.timestamp.isoformat(),
        }

    @staticmethod
    def _deserialise_result(value: dict[str, object]) -> ScraperResult:
        price = value.get("price")
        timestamp = value.get("timestamp")
        return ScraperResult(
            product_name=str(value["product_name"]),
            brand=str(value["brand"]) if value.get("brand") is not None else None,
            price=Decimal(str(price)) if price is not None else None,
            stock=str(value["stock"]) if value.get("stock") is not None else None,
            url=str(value["url"]),
            confidence=float(value["confidence"]),
            timestamp=datetime.fromisoformat(str(timestamp)) if timestamp else datetime.utcnow(),
        )
