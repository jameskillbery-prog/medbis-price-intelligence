"""Competitor scraper framework."""

