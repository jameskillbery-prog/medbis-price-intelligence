# MedBIS Price Intelligence

MedBIS Price Intelligence is a Windows desktop application for importing MedBIS product data, storing it in SQLite, and preparing the foundation for competitor price intelligence workflows.

This ZIP contains **Milestone 1 only**:

- Project structure
- SQLite database models
- SQLAlchemy session/repository layer
- CustomTkinter desktop shell
- Excel/CSV import engine with automatic column detection
- Basic dashboard statistics and import history

## Milestone 2 Additions

This package also includes the Milestone 2 foundation:

- RapidFuzz weighted matching engine
- Automatic match/review/ignore thresholds
- Base scraper contract for every competitor website
- Normalised scraper query/result models
- Async Playwright scraper runner with concurrency limit
- SQLite-backed scraper search cache

Suggested first commit message after upload:

```text
Initialize MedBIS Price Intelligence desktop app
```

## Requirements

- Python 3.12
- Windows 10 or later

## Setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Run

```powershell
python -m medbis_price_intelligence
```

## Importing Products

The importer accepts `.xlsx`, `.xls`, and `.csv` files. It automatically maps likely columns for:

- SKU
- Product name
- Brand
- Pack size
- Quantity
- Strength
- Cost price
- Selling price
- Category
- Barcode

Imported products are stored in SQLite at:

```text
data/medbis_price_intelligence.sqlite3
```

## Test

```powershell
python -m compileall src tests
python -m pytest
```

## Next Milestone

Milestone 3 should add the first real competitor scrapers, starting with Medisave and Medical World.

Suggested second commit message:

```text
Add matching engine and scraper framework
```
