# MedBIS Price Intelligence

MedBIS Price Intelligence is a Windows desktop application for importing MedBIS product data, storing it in SQLite, and preparing the foundation for competitor price intelligence workflows.

This ZIP contains **Milestone 1 only**:

- Project structure
- SQLite database models
- SQLAlchemy session/repository layer
- CustomTkinter desktop shell
- Excel/CSV import engine with automatic column detection
- Basic dashboard statistics and import history

Suggested first commit message after upload:

```text
Initialize MedBIS Price Intelligence desktop app
```

## Requirements

- Python 3.12
- Windows 10 or later

## Setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Run

```powershell
python -m medbis_price_intelligence
```

## Importing Products

The importer accepts `.xlsx`, `.xls`, and `.csv` files. It automatically maps likely columns for:

- SKU
- Product name
- Brand
- Pack size
- Quantity
- Strength
- Cost price
- Selling price
- Category
- Barcode

Imported products are stored in SQLite at:

```text
data/medbis_price_intelligence.sqlite3
```

## Test

```powershell
python -m compileall src tests
python -m pytest
```

## Next Milestone

Milestone 2 should add the RapidFuzz matching engine and the base scraper framework.

