from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

from medbis_price_intelligence.config import AppConfig
from medbis_price_intelligence.database.repositories import (
    CompetitorRepository,
    ProductRepository,
    RunRepository,
)
from medbis_price_intelligence.database.session import Database
from medbis_price_intelligence.importer.importer import ProductImporter
from medbis_price_intelligence.ui.theme import apply_theme


class MainWindow(ctk.CTk):
    """Main CustomTkinter desktop shell."""

    def __init__(self, config: AppConfig, database: Database) -> None:
        apply_theme()
        super().__init__()
        self.config = config
        self.database = database

        self.title(config.app_name)
        self.geometry("1180x720")
        self.minsize(980, 620)

        self.status_text = ctk.StringVar(value="Ready")
        self.product_count = ctk.StringVar(value="0")
        self.competitor_count = ctk.StringVar(value="0")
        self.import_count = ctk.StringVar(value="0")

        self._ensure_competitors()
        self._build_layout()
        self.refresh_stats()

    def _build_layout(self) -> None:
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        sidebar = ctk.CTkFrame(self, width=220, corner_radius=0)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_rowconfigure(7, weight=1)

        ctk.CTkLabel(sidebar, text="MedBIS", font=ctk.CTkFont(size=28, weight="bold")).grid(
            row=0, column=0, padx=22, pady=(28, 2), sticky="w"
        )
        ctk.CTkLabel(sidebar, text="Price Intelligence").grid(
            row=1, column=0, padx=22, pady=(0, 28), sticky="w"
        )

        ctk.CTkButton(sidebar, text="Dashboard", command=self.refresh_stats).grid(
            row=2, column=0, padx=18, pady=8, sticky="ew"
        )
        ctk.CTkButton(sidebar, text="Import Products", command=self.import_products).grid(
            row=3, column=0, padx=18, pady=8, sticky="ew"
        )
        ctk.CTkButton(sidebar, text="Refresh", command=self.refresh_stats).grid(
            row=4, column=0, padx=18, pady=8, sticky="ew"
        )

        content = ctk.CTkFrame(self, corner_radius=0)
        content.grid(row=0, column=1, sticky="nsew")
        content.grid_columnconfigure((0, 1, 2), weight=1)
        content.grid_rowconfigure(3, weight=1)

        ctk.CTkLabel(content, text="Dashboard", font=ctk.CTkFont(size=26, weight="bold")).grid(
            row=0, column=0, columnspan=3, padx=28, pady=(28, 8), sticky="w"
        )

        self._stat_card(content, "Products", self.product_count, 0)
        self._stat_card(content, "Competitors", self.competitor_count, 1)
        self._stat_card(content, "Imports", self.import_count, 2)

        toolbar = ctk.CTkFrame(content)
        toolbar.grid(row=2, column=0, columnspan=3, padx=28, pady=18, sticky="ew")
        toolbar.grid_columnconfigure(0, weight=1)

        self.search_box = ctk.CTkEntry(toolbar, placeholder_text="Search and filtering")
        self.search_box.grid(row=0, column=0, padx=14, pady=14, sticky="ew")
        ctk.CTkButton(toolbar, text="Import Excel/CSV", command=self.import_products).grid(
            row=0, column=1, padx=(0, 14), pady=14
        )

        panel = ctk.CTkTextbox(content)
        panel.grid(row=3, column=0, columnspan=3, padx=28, pady=(0, 18), sticky="nsew")
        panel.insert(
            "1.0",
            "Milestone 1 is ready.\n\n"
            "Use Import Products to load your MedBIS Excel or CSV product list into SQLite.\n"
            "Matching, scrapers, charts, and reports are planned for later milestones.",
        )
        panel.configure(state="disabled")

        status = ctk.CTkLabel(content, textvariable=self.status_text, anchor="w")
        status.grid(row=4, column=0, columnspan=3, padx=28, pady=(0, 18), sticky="ew")

    def _stat_card(
        self,
        parent: ctk.CTkFrame,
        label: str,
        value: ctk.StringVar,
        column: int,
    ) -> None:
        card = ctk.CTkFrame(parent)
        card.grid(row=1, column=column, padx=28 if column == 0 else 8, pady=18, sticky="ew")
        ctk.CTkLabel(card, text=label).grid(row=0, column=0, padx=18, pady=(16, 4), sticky="w")
        ctk.CTkLabel(card, textvariable=value, font=ctk.CTkFont(size=34, weight="bold")).grid(
            row=1, column=0, padx=18, pady=(0, 16), sticky="w"
        )

    def import_products(self) -> None:
        file_name = filedialog.askopenfilename(
            title="Import MedBIS product list",
            filetypes=[
                ("Excel files", "*.xlsx *.xls"),
                ("CSV files", "*.csv"),
                ("All files", "*.*"),
            ],
        )
        if not file_name:
            return

        try:
            with self.database.session() as session:
                result = ProductImporter(session).import_file(Path(file_name))
            self.status_text.set(f"Imported {result.products_saved} products from {result.source_file.name}")
            self.refresh_stats()
            messagebox.showinfo("Import complete", f"Imported {result.products_saved} products.")
        except Exception as exc:
            self.status_text.set("Import failed")
            messagebox.showerror("Import failed", str(exc))

    def refresh_stats(self) -> None:
        with self.database.session() as session:
            products = ProductRepository(session).count()
            competitors = CompetitorRepository(session).count_enabled()
            imports = RunRepository(session).count_imports()
        self.product_count.set(str(products))
        self.competitor_count.set(str(competitors))
        self.import_count.set(str(imports))

    def _ensure_competitors(self) -> None:
        with self.database.session() as session:
            CompetitorRepository(session).ensure_defaults()
